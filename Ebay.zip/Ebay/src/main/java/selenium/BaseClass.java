package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BaseClass {
    public static WebDriver driver;

    // Method to launch either Chrome or Edge based on input
    public static void launchBrowser(String browser) {
        if (browser.equalsIgnoreCase("chrome")) {
        	  //set path for ChromeDriver
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\2425750\\Downloads\\chromedrivernew\\chromedriver-win64\\chromedriver.exe");
            driver = new ChromeDriver();
        } else if (browser.equalsIgnoreCase("edge")) {
        	  //set path for EdgeDriver
            System.setProperty("webdriver.edge.driver", "C:\\Users\\2425750\\Downloads\\edgedriver\\msedgedriver.exe");
            driver = new EdgeDriver();
        } else {
            System.out.println("Unsupported browser");
            return;
        }
        
      //maximize window and set implicit wait
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

    // Wait for a fixed number of seconds
    public static void waitInSeconds(int seconds) {
        try {
            Thread.sleep(seconds * 1000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
